<?php

if (!function_exists("_")){
	function _($text){
		return $text;
	}
}
?>
