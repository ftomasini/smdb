ALTER TABLE config.t_node ADD COLUMN connuser text;
ALTER TABLE config.t_node ADD COLUMN connpass text;

